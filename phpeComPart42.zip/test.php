<?php
session_start();
//unset($_SESSION['cart']);
echo "<pre>";
print_r($_SESSION['cart']);
?>